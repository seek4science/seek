print("No license here")
