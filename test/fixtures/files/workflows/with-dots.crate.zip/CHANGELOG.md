0.1
---------
- Initial version of COVID-19: variation analysis on ARTIC ONT data workflow
